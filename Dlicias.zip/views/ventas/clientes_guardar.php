<?php require_once "../../controladores/clientes.php"; 
registrarCliente();
header('Location: index.php'); ?>