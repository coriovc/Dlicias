<?php require_once "../../controladores/producto.php"; 
registrarProducto();
header('Location: ../inventario/index.php'); ?>