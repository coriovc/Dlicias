<!-- Modal Cerrar Sesion-->


  <div class="modal tct fade modaldark" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
    
  <section class="modal-dialog Exit-section" role="document">
      <div class="modal-content container">
          <div class="row align-items-center d-flex d-xl-none">
            <div class="col-12 col-lg-5 home-content">
                <h2>Cerrar Sesion</h2>
                <h4>Esta seguro de que desea Salir?</h4>
            <button type="button" data-dismiss="modal" aria-label="Close" class="btn btn-white mr-2 shadow-lg rounded-pill lift-X-r">Cancelar
            <i class="material-icons-round ml-2">No</i></button>
            <a href="../../php/logout.php" class="btn btn-danger shadow-lg rounded-pill lift-X-r">SI
            <i class="material-icons-round ml-2">exit_to_app</i></a>                     
              </div> 
          </div>
          <div class="row height-100 align-items-center justify-content-center">
              <div class="col-12 col-lg-5 home-content d-none d-xl-block">
                <h2>Cerrar Sesion</h2>
                <h4>Esta seguro de que desea Salir?</h4>
            <button type="button" data-dismiss="modal" aria-label="Close" class="btn btn-white mr-2 shadow-lg rounded-pill lift-X-r">NO<i class="material-icons-round ml-2">cancel</i></button>
            <a href="../../php/logout.php" class="btn btn-danger shadow-lg rounded-pill lift-X-r">SI<i class="material-icons-round ml-2">exit_to_app</i></a>                    
              </div>            
          </div>          
        </div>
    </section>
  </div>

<!-- Modal Cerrar Sesion home-->
  <div class="modal tct fade filter-modal modaldark" id="logoutModalHome" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
    <section class="modal-dialog Exit-section" role="document">
      <div class="modal-content container">
          <div class="row align-items-center d-flex d-xl-none">
            <div class="col-12 col-lg-5 home-content">
                <h2>Cerrar Sesion</h2>
                <h4>Esta seguro de que desea Salir?</h4>
            <button type="button" data-dismiss="modal" aria-label="Close" class="btn btn-white mr-2 shadow-lg rounded-pill lift-X-r">Cancelar
            <i class="material-icons-round ml-2">No</i></button>
            <a href="php/logout.php" class="btn btn-danger shadow-lg rounded-pill lift-X-r">SI
            <i class="material-icons-round ml-2">exit_to_app</i></a>                     
              </div> 
          </div>
          <div class="row height-100 align-items-center justify-content-center">
              <div class="col-12 col-lg-5 home-content d-none d-xl-block">
                <h2>Cerrar Sesion</h2>
                <h4>Esta seguro de que desea Salir?</h4>
            <button type="button" data-dismiss="modal" aria-label="Close" class="btn btn-white mr-2 shadow-lg rounded-pill lift-X-r">NO<i class="material-icons-round ml-2">cancel</i></button>
            <a href="php/logout.php" class="btn btn-danger shadow-lg rounded-pill lift-X-r">SI<i class="material-icons-round ml-2">exit_to_app</i></a>                    
              </div>            
          </div>          
        </div>
    </section>
  </div>