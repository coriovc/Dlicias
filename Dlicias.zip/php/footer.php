<footer class="tct py-3"><!-- Footer -->
  <div class="align-content-center text-center align-items-center py-3">
    <h6>Designed by OcorCode © 2020 Copyright :<a class="ml-2" href="https://sites.ocor.com/">Ocor.com</a></h6>
  </div>
</footer>

<!--<div class="d-inline d-md-none">
        <a class="btn btn-sm btn-transparent-light btn-icon ml-2" id="footer-t&c" href="javascript:newVentana('error-404.php')">
          <span class="material-icons-round">wysiwyg</span></a>
        </div>
        <div class="d-none  d-md-inline">
          <a class="btn btn-sm btn-transparent-light rounded-pill ml-2" href="javascript:newVentana('error-404.php')">
          <span class="material-icons-round mr-2">wysiwyg</span>Terminos & Condiciones</a>
        </div>

        <script language=javascript>function newVentana (url){window.open(url, "Terminos y Condiciones", "width=800, height=500")}</script>-->